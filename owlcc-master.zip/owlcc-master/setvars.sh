echo "+++ Set variables."
# ------------------------------------------------------------------------------
ACCOUNT_SID=your_account_SID
AUTH_TOKEN=your_account_auth_token
WORKSPACE_SID=your_TaskRouter_workspace_SID
export ACCOUNT_SID
export AUTH_TOKEN
export WORKSPACE_SID
echo "+ Variables set."
php echoVars.php
# ------------------------------------------------------------------------------
