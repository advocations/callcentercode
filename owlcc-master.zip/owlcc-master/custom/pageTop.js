document.write('<div id="topBar">');
document.write('<table><tr>');
document.write('<td><a href="/index.html"><img src="custom/companyLogo.jpg" alt="Twilio" style="width:120px; padding-right: 30px;"/></a></td>');
document.write('<td><h1>Owl Call Center</h1></td>');
document.write('</tr></table>');
document.write('<hr>');
document.write('</div>');
