document.write('<div id="bottomBar">');
// document.write('<hr>');
// Centered:
// Logo, just the logo.
document.write('<img src="custom/logo.jpg" alt="Twilio"/>');
document.write('<div id="bottomContent">');
document.write('<div style="padding-bottom: 10px;"><a href="https://github.com/tigerfarm/owlcc" style="color: rgba(255,255,255,.65);">GitHub project</a></div>');
document.write('<a href="https://twilio.learnupon.com/store" style="color: rgba(255,255,255,.65);">Training</a>');
document.write(' | <a href="https://www.twilio.com/support-plans" style="color: rgba(255,255,255,.65);">Support</a>');
document.write(' | <a href="https://www.twilio.com/company" style="color: rgba(255,255,255,.65);">About Twilio</a>');
document.write('</div>');

document.write('<div style="padding-top: 10px;">2018 Twilio</div>');
document.write('</div>');
